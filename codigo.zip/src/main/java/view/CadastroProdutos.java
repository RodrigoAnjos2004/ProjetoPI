package view;

import model.Produto;
import controller.ProdutoController;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class CadastroProdutos extends javax.swing.JFrame {
    public String modoTela = "Criar";
    Produto objProduto;

    public CadastroProdutos() {
        initComponents();
        setResizable(false); //Impedir alteração no tamanho da tela       
        setLocationRelativeTo(null); //deixar centralizado na tela do monitor
        this.setTitle("Loja de Artigos Esportivos,"); //altera titulo da janela
        objProduto = new Produto();

        //Carregar todos os produtos na tabela ao iniciar este JFrame
        CarregarJTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlCadastroProdutos = new javax.swing.JPanel();
        lblNomeProduto = new javax.swing.JLabel();
        lblDescricaoProduto = new javax.swing.JLabel();
        lblQuantidadeProduto = new javax.swing.JLabel();
        lblPrecoProduto = new javax.swing.JLabel();
        txtNomeProduto = new javax.swing.JTextField();
        txtDescricaoProduto = new javax.swing.JTextField();
        txtQuantidadeProduto = new javax.swing.JTextField();
        btnSalvarProduto = new javax.swing.JButton();
        btnLimparProduto = new javax.swing.JButton();
        txtPrecoProduto = new javax.swing.JTextField();
        lblConsultaNome = new javax.swing.JLabel();
        lblConsultaDescricao = new javax.swing.JLabel();
        txtConsultaNomeProd = new javax.swing.JTextField();
        txtConsultaIdProd = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProdutos = new javax.swing.JTable();
        btnRemoverProduto = new javax.swing.JButton();
        btnAlterarProduto = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuOpcoes = new javax.swing.JMenu();
        opMenuPrincipal = new javax.swing.JMenuItem();
        opCadastroClientes = new javax.swing.JMenuItem();
        opTelaVendas = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        opSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNomeProduto.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblNomeProduto.setText("Nome:");

        lblDescricaoProduto.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblDescricaoProduto.setText("Descrição:");

        lblQuantidadeProduto.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblQuantidadeProduto.setText("Quantidade:");

        lblPrecoProduto.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblPrecoProduto.setText("Preço:");

        txtNomeProduto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNomeProdutoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNomeProdutoFocusLost(evt);
            }
        });
        txtNomeProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeProdutoActionPerformed(evt);
            }
        });

        txtDescricaoProduto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDescricaoProdutoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDescricaoProdutoFocusLost(evt);
            }
        });

        txtQuantidadeProduto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtQuantidadeProdutoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtQuantidadeProdutoFocusLost(evt);
            }
        });

        btnSalvarProduto.setText("Salvar");
        btnSalvarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarProdutoActionPerformed(evt);
            }
        });

        btnLimparProduto.setText("Limpar");
        btnLimparProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparProdutoActionPerformed(evt);
            }
        });

        lblConsultaNome.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblConsultaNome.setText("Nome:");

        lblConsultaDescricao.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblConsultaDescricao.setText("ID:");

        txtConsultaNomeProd.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtConsultaNomeProdFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtConsultaNomeProdFocusLost(evt);
            }
        });

        txtConsultaIdProd.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtConsultaIdProdFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtConsultaIdProdFocusLost(evt);
            }
        });

        tblProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nome", "Qtd", "Preço"
            }
        ));
        tblProdutos.setToolTipText("");
        jScrollPane1.setViewportView(tblProdutos);

        btnRemoverProduto.setText("Remover");
        btnRemoverProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverProdutoActionPerformed(evt);
            }
        });

        btnAlterarProduto.setText("Alterar");
        btnAlterarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarProdutoActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("CADASTRO PRODUTOS");

        javax.swing.GroupLayout pnlCadastroProdutosLayout = new javax.swing.GroupLayout(pnlCadastroProdutos);
        pnlCadastroProdutos.setLayout(pnlCadastroProdutosLayout);
        pnlCadastroProdutosLayout.setHorizontalGroup(
            pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRemoverProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAlterarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 905, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                                    .addComponent(lblDescricaoProduto)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtDescricaoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 819, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                                    .addComponent(lblConsultaNome)
                                    .addGap(43, 43, 43)
                                    .addComponent(txtConsultaNomeProd, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(84, 84, 84)
                                    .addComponent(lblConsultaDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtConsultaIdProd, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                                    .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel1)
                                        .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                                            .addComponent(lblNomeProduto)
                                            .addGap(42, 42, 42)
                                            .addComponent(txtNomeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(lblQuantidadeProduto)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtQuantidadeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(59, 59, 59)
                                    .addComponent(lblPrecoProduto)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtPrecoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(55, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCadastroProdutosLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSalvarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(btnLimparProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(296, 296, 296))
        );

        pnlCadastroProdutosLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtPrecoProduto, txtQuantidadeProduto});

        pnlCadastroProdutosLayout.setVerticalGroup(
            pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCadastroProdutosLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(41, 41, 41)
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNomeProduto)
                    .addComponent(txtNomeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblQuantidadeProduto)
                    .addComponent(txtQuantidadeProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrecoProduto)
                    .addComponent(txtPrecoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescricaoProduto)
                    .addComponent(txtDescricaoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimparProduto)
                    .addComponent(btnSalvarProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(85, 85, 85)
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblConsultaNome)
                    .addComponent(txtConsultaNomeProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblConsultaDescricao)
                    .addComponent(txtConsultaIdProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCadastroProdutosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBuscar)
                    .addComponent(btnRemoverProduto)
                    .addComponent(btnAlterarProduto))
                .addGap(26, 26, 26))
        );

        pnlCadastroProdutosLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtPrecoProduto, txtQuantidadeProduto});

        menuOpcoes.setText("Opções");

        opMenuPrincipal.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_DOWN_MASK));
        opMenuPrincipal.setText("Menu Principal");
        opMenuPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opMenuPrincipalActionPerformed(evt);
            }
        });
        menuOpcoes.add(opMenuPrincipal);

        opCadastroClientes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_DOWN_MASK));
        opCadastroClientes.setText("Cadastro de Clientes");
        opCadastroClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opCadastroClientesActionPerformed(evt);
            }
        });
        menuOpcoes.add(opCadastroClientes);

        opTelaVendas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.ALT_DOWN_MASK));
        opTelaVendas.setText("Tela de Vendas");
        opTelaVendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opTelaVendasActionPerformed(evt);
            }
        });
        menuOpcoes.add(opTelaVendas);
        menuOpcoes.add(jSeparator1);

        opSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_DOWN_MASK));
        opSair.setText("Sair");
        opSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opSairActionPerformed(evt);
            }
        });
        menuOpcoes.add(opSair);

        jMenuBar1.add(menuOpcoes);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlCadastroProdutos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlCadastroProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarProdutoActionPerformed
        String nome = txtNomeProduto.getText().trim();
        String descricao = txtDescricaoProduto.getText().trim();
        String quantidadeString = txtQuantidadeProduto.getText().trim();
        String precoString = txtPrecoProduto.getText().trim();

        //Validando a obrigatoriedade do nome
        if (nome.equals("")) {
            JOptionPane.showMessageDialog(this, "Digite o nome o produto!");
            return;
        }

        //Validando a obrigatoriedade da descrição
        if (descricao.equals("")) {
            JOptionPane.showMessageDialog(this, "Digite a descrição do produto!");           
            return;       
        }

        //Validando a obrigatoriedade da quantidade
        int qtd = 0;
        if (quantidadeString.equals("")) {
            JOptionPane.showMessageDialog(this, "Digite a quantidade do produto!");            
            return;
        } else {
            try {
                qtd = Integer.parseInt(txtQuantidadeProduto.getText());
            } catch (NumberFormatException erro){ //Caso o usuário não digitar um número  
                JOptionPane.showMessageDialog(this, "Digite somente número no campo quantidade!");             
                return;
            }
        }

        //Validando a quantidade do preço
        double preco = 0.0f;
        if(precoString.equals("")) {
            JOptionPane.showMessageDialog(this, "Digite o preço do produto!");           
            return;                     
        } else {
            try {
                preco = Double.parseDouble(precoString.replace(",", "."));
            } catch (NumberFormatException erro){ //Caso o usuário não digitar um número  
                JOptionPane.showMessageDialog(this, "Digite somente número no campo quantidade!");             
                return;
            }
        }

        boolean retorno = false;
        objProduto.setNome(nome);
        objProduto.setDescricao(descricao);
        objProduto.setQtd(qtd);
        objProduto.setPreco(preco);

        if (modoTela.equals("Criação")) {
            try {
                retorno = ProdutoController.salvar(objProduto);
            } catch (ClassNotFoundException ex) {
                System.out.println("ERROR!");
            }

            if (retorno) {
                JOptionPane.showMessageDialog(null, "Produto cadastrada com sucesso.", "Cadastro realizado", JOptionPane.INFORMATION_MESSAGE);
                CarregarJTable();
                txtNomeProduto.setText("");
                txtDescricaoProduto.setText("");
                txtQuantidadeProduto.setText("");
                txtPrecoProduto.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao cadastrar o produto!", "Falha", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            try {
                retorno = ProdutoController.alteracaoSalvar(objProduto);
                CarregarJTable();
                txtNomeProduto.setText("");
                txtDescricaoProduto.setText("");
                txtQuantidadeProduto.setText("");
                txtPrecoProduto.setText("");
                
                modoTela = "Criação";
                this.btnSalvarProduto.setText("Salvar");
            } catch (Exception e) {
                System.out.println("ERROR!");
            }

            if (retorno) {
                JOptionPane.showMessageDialog(null, "Produto alterado com sucesso.", "Compra alterada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao alterar o produto!", "Falha", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnSalvarProdutoActionPerformed

    private void btnLimparProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparProdutoActionPerformed
        txtNomeProduto.setText("");
        txtDescricaoProduto.setText("");
        txtQuantidadeProduto.setText("");
        txtPrecoProduto.setText("");           
    }//GEN-LAST:event_btnLimparProdutoActionPerformed

    private void opMenuPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opMenuPrincipalActionPerformed
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_opMenuPrincipalActionPerformed

    private void opCadastroClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opCadastroClientesActionPerformed
        CadastroClientes telaCadastroClientes = new  CadastroClientes();
        telaCadastroClientes.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_opCadastroClientesActionPerformed

    private void opTelaVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opTelaVendasActionPerformed
        TelaVenda telaVenda = new TelaVenda();
        telaVenda.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_opTelaVendasActionPerformed

    private void opSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_opSairActionPerformed

    private void txtNomeProdutoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNomeProdutoFocusGained
        txtNomeProduto.setBackground(new Color(151,255,255));
    }//GEN-LAST:event_txtNomeProdutoFocusGained

    private void txtNomeProdutoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNomeProdutoFocusLost
        txtNomeProduto.setBackground(Color.white);
    }//GEN-LAST:event_txtNomeProdutoFocusLost

    private void txtDescricaoProdutoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescricaoProdutoFocusGained
        txtDescricaoProduto.setBackground(new Color(151,255,255));
    }//GEN-LAST:event_txtDescricaoProdutoFocusGained

    private void txtDescricaoProdutoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescricaoProdutoFocusLost
        txtDescricaoProduto.setBackground(Color.white);
    }//GEN-LAST:event_txtDescricaoProdutoFocusLost

    private void txtQuantidadeProdutoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQuantidadeProdutoFocusGained
        txtQuantidadeProduto.setBackground(new Color(151,255,255));
    }//GEN-LAST:event_txtQuantidadeProdutoFocusGained

    private void txtQuantidadeProdutoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQuantidadeProdutoFocusLost
        txtQuantidadeProduto.setBackground(Color.white);
    }//GEN-LAST:event_txtQuantidadeProdutoFocusLost

    private void txtConsultaNomeProdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtConsultaNomeProdFocusGained
        txtConsultaNomeProd.setBackground(new Color(151,255,255));
    }//GEN-LAST:event_txtConsultaNomeProdFocusGained

    private void txtConsultaNomeProdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtConsultaNomeProdFocusLost
       txtConsultaNomeProd.setBackground(Color.white);
    }//GEN-LAST:event_txtConsultaNomeProdFocusLost

    private void txtConsultaIdProdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtConsultaIdProdFocusGained
        txtConsultaIdProd.setBackground(new Color(151,255,255));
    }//GEN-LAST:event_txtConsultaIdProdFocusGained

    private void txtConsultaIdProdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtConsultaIdProdFocusLost
        txtConsultaIdProd.setBackground(Color.white);
    }//GEN-LAST:event_txtConsultaIdProdFocusLost

    private void txtNomeProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeProdutoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String nomeProd = txtConsultaNomeProd.getText();
        String idProd = txtConsultaIdProd.getText();
        ArrayList<String[]> listaProduto = null;

        int idProdConvert = 0;
        if (!idProd.equals("")) {
            try {
                idProdConvert = Integer.parseInt(idProd);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Erro na conversão do ID!", "Erro Conversão", JOptionPane.ERROR);
            }
        }

        listaProduto = ProdutoController.pesquisaPorNomeOuId(nomeProd, idProdConvert);

        DefaultTableModel tmProduto = new DefaultTableModel();
        tmProduto.addColumn("Id");
        tmProduto.addColumn("Nome");
        tmProduto.addColumn("Descrição");
        tmProduto.addColumn("Qtd");
        tmProduto.addColumn("Preço");
        tblProdutos.setModel(tmProduto);

        tmProduto.setRowCount(0);

        for (String[] item : listaProduto) {
            tmProduto.addRow(item);
        }
        tblProdutos.getColumnModel().getColumn(0).setPreferredWidth(50); //Id
        tblProdutos.getColumnModel().getColumn(1).setPreferredWidth(150); // Nome
        tblProdutos.getColumnModel().getColumn(2).setPreferredWidth(200); // Descricao
        tblProdutos.getColumnModel().getColumn(3).setPreferredWidth(65); // Qtd
        tblProdutos.getColumnModel().getColumn(4).setPreferredWidth(80); // Preço
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnAlterarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarProdutoActionPerformed
        if(tblProdutos.getSelectedRow() != -1) {
            int numeroLinha = tblProdutos.getSelectedRow();

            int idProd = Integer.parseInt(tblProdutos.getModel().getValueAt(numeroLinha, 0).toString());
            String nome = tblProdutos.getModel().getValueAt(numeroLinha, 1).toString();
            String descricao = tblProdutos.getModel().getValueAt(numeroLinha, 2).toString();
            int qtd = Integer.parseInt(tblProdutos.getModel().getValueAt(numeroLinha, 3).toString());
            double preco = Double.parseDouble(tblProdutos.getModel().getValueAt(numeroLinha, 4).toString().replace(",", "."));

            txtNomeProduto.setText(nome);
            txtDescricaoProduto.setText(descricao);
            txtQuantidadeProduto.setText(String.valueOf(qtd));
            txtPrecoProduto.setText(String.valueOf(preco).replace(".", ","));

            objProduto.setId(idProd);
            objProduto.setNome(nome);
            objProduto.setDescricao(descricao);
            objProduto.setQtd(qtd);
            objProduto.setPreco(preco);

            modoTela = "Alteração";
            this.btnSalvarProduto.setText("Alterar");
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um produto da tabela!", "Operação Inválida", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnAlterarProdutoActionPerformed

    private void btnRemoverProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverProdutoActionPerformed
        if(tblProdutos.getSelectedRow() != -1) {
            int numeroLinha = tblProdutos.getSelectedRow();
            int idProduto = Integer.parseInt(tblProdutos.getModel().getValueAt(numeroLinha, 0).toString());
            try {
                if(ProdutoController.exclusao(idProduto)){
                    JOptionPane.showMessageDialog(this, "Produto excluído com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(this, "Falha ao excluir produto!", "Falha", JOptionPane.ERROR_MESSAGE);
                }
            } catch (ClassNotFoundException ex) {
                System.out.println("ERROR!");
            }
            CarregarJTable();

        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha!", "Operação Inválida", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnRemoverProdutoActionPerformed

    public void CarregarJTable() {
        ArrayList<String[]> listaProduto = ProdutoController.listar();
        DefaultTableModel tmProduto = new DefaultTableModel();
        tmProduto.addColumn("Id");
        tmProduto.addColumn("Nome");
        tmProduto.addColumn("Descrição");
        tmProduto.addColumn("Qtd");
        tmProduto.addColumn("Preço");

        tblProdutos.setModel(tmProduto);
        tmProduto.setRowCount(0);

        for (String[] item : listaProduto) {
            tmProduto.addRow(item);
        }

        tblProdutos.getColumnModel().getColumn(0).setPreferredWidth(50); //Id
        tblProdutos.getColumnModel().getColumn(1).setPreferredWidth(150); // Nome
        tblProdutos.getColumnModel().getColumn(2).setPreferredWidth(200); // Descricao
        tblProdutos.getColumnModel().getColumn(3).setPreferredWidth(65); // Qtd
        tblProdutos.getColumnModel().getColumn(4).setPreferredWidth(80); // Preço
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Metal".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroProdutos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroProdutos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterarProduto;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnLimparProduto;
    private javax.swing.JButton btnRemoverProduto;
    private javax.swing.JButton btnSalvarProduto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JLabel lblConsultaDescricao;
    private javax.swing.JLabel lblConsultaNome;
    private javax.swing.JLabel lblDescricaoProduto;
    private javax.swing.JLabel lblNomeProduto;
    private javax.swing.JLabel lblPrecoProduto;
    private javax.swing.JLabel lblQuantidadeProduto;
    private javax.swing.JMenu menuOpcoes;
    private javax.swing.JMenuItem opCadastroClientes;
    private javax.swing.JMenuItem opMenuPrincipal;
    private javax.swing.JMenuItem opSair;
    private javax.swing.JMenuItem opTelaVendas;
    private javax.swing.JPanel pnlCadastroProdutos;
    private javax.swing.JTable tblProdutos;
    private javax.swing.JTextField txtConsultaIdProd;
    private javax.swing.JTextField txtConsultaNomeProd;
    private javax.swing.JTextField txtDescricaoProduto;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtPrecoProduto;
    private javax.swing.JTextField txtQuantidadeProduto;
    // End of variables declaration//GEN-END:variables
}
