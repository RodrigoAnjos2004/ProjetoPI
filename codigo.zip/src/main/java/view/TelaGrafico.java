package view;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import com.toedter.calendar.JSpinnerDateEditor;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class TelaGrafico extends JFrame {

    private JDateChooser dateChooserInicio;
    private JDateChooser dateChooserFim;
    private JComboBox<String> comboProdutos; // ComboBox para seleção de produtos
    private JTable tabelaResultado;
    private DefaultTableModel tableModel;

    private static TelaGrafico instancia;

    public TelaGrafico(String title) {
        super(title);
        instancia = this;
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Gráfico de Vendas por Dia", createPieChartPanel());

        // Adicione um título à aba "Pesquisar Vendas por Data" com o mesmo nome
        tabbedPane.addTab("Pesquisar Vendas por Data", createSearchPanel());

        getContentPane().add(tabbedPane);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private JPanel createPieChartPanel() {
        DefaultPieDataset dataset = createDatasetPie();

        JFreeChart chart = createPieChart(dataset);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 600));

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(chartPanel, BorderLayout.CENTER);

        return panel;
    }

    private DefaultPieDataset createDatasetPie() {
        DefaultPieDataset dataset = new DefaultPieDataset();

        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost/pitest";
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);

            String sql = "SELECT data_venda, COUNT(*) AS num_vendas FROM venda "
                    + "GROUP BY data_venda";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String dataVenda = resultSet.getString("data_venda");
                int numVendas = resultSet.getInt("num_vendas");
                dataset.setValue(dataVenda, numVendas);
            }
            resultSet.close();
            statement.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return dataset;
    }

    private JFreeChart createPieChart(DefaultPieDataset dataset) {
        JFreeChart chart = ChartFactory.createPieChart(
                "Gráfico de Vendas por Dia",
                dataset,
                true,
                true,
                false
        );

        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setSectionOutlinesVisible(false);
        plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
        plot.setCircular(true);
        plot.setLabelGap(0.02);

        return chart;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(10, 10, 10, 10);

        JLabel lblTitulo = new JLabel("Pesquisar Vendas por Data e Produto");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18)); // Defina a fonte e tamanho desejados
        panel.add(lblTitulo, constraints);

        JLabel lblDataInicio = new JLabel("Data de Início:");
        constraints.gridx = 0;
        constraints.gridy = 1;
        panel.add(lblDataInicio, constraints);

        dateChooserInicio = new JDateChooser();
        dateChooserInicio.setDateFormatString("yyyy-MM-dd");
        JTextFieldDateEditor dateEditorInicio = (JTextFieldDateEditor) dateChooserInicio.getDateEditor();
        dateEditorInicio.setEditable(false);
        constraints.gridx = 1;
        panel.add(dateChooserInicio, constraints);

        JLabel lblDataFim = new JLabel("Data de Fim:");
        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(lblDataFim, constraints);

        dateChooserFim = new JDateChooser();
        dateChooserFim.setDateFormatString("yyyy-MM-dd");
        JTextFieldDateEditor dateEditorFim = (JTextFieldDateEditor) dateChooserFim.getDateEditor();
        dateEditorFim.setEditable(false);
        constraints.gridx = 1;
        panel.add(dateChooserFim, constraints);

        JLabel lblProduto = new JLabel("Selecione o Produto:");
        constraints.gridx = 0;
        constraints.gridy = 3;
        panel.add(lblProduto, constraints);

        comboProdutos = new JComboBox<>(); // ComboBox para seleção de produtos
        constraints.gridx = 1;
        panel.add(comboProdutos, constraints);

        JButton btnPesquisar = new JButton("Pesquisar");
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(btnPesquisar, constraints);

        JButton btnPesquisarTodas = new JButton("Pesquisar Todas as Vendas"); // Botão para pesquisar todas as vendas
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        panel.add(btnPesquisarTodas, constraints);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Data da Venda");
        tableModel.addColumn("Nome do Cliente");
        tableModel.addColumn("Produto");

        tabelaResultado = new JTable(tableModel);
        tabelaResultado.setPreferredScrollableViewportSize(new Dimension(700, 300));

        JScrollPane scrollPane = new JScrollPane(tabelaResultado);
        constraints.gridx = 0;
        constraints.gridy = 6; // Ajuste a posição do painel de resultados
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.BOTH;
        panel.add(scrollPane, constraints);

        btnPesquisar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pesquisarVendasPorDataEProduto();
            }
        });

        btnPesquisarTodas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pesquisarTodasVendas();
            }
        });

        // Preencher o ComboBox com produtos
        preencherProdutos();

        return panel;
    }

    private void preencherProdutos() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/pitest";
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);

            String sql = "SELECT nome FROM produto";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            while (resultSet.next()) {
                String nomeProduto = resultSet.getString("nome");
                comboBoxModel.addElement(nomeProduto);
            }

            comboProdutos.setModel(comboBoxModel);

            resultSet.close();
            statement.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void pesquisarVendasPorDataEProduto() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dataInicio = dateChooserInicio.getDate();
        Date dataFim = dateChooserFim.getDate();

        String produtoSelecionado = comboProdutos.getSelectedItem().toString();

        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/homologacao";
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);

            String sql = "SELECT v.data_venda, c.nome as nome_cliente, p.nome as nome_produto "
                    + "FROM venda v "
                    + "INNER JOIN cliente c ON v.fk_cliente = c.id "
                    + "INNER JOIN item_venda vp ON v.id = vp.id_venda "
                    + "INNER JOIN produto p ON vp.id_produto = p.id "
                    + "WHERE v.data_venda BETWEEN ? AND ? "
                    + "AND p.nome = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setDate(1, new java.sql.Date(dataInicio.getTime()));
            statement.setDate(2, new java.sql.Date(dataFim.getTime()));
            statement.setString(3, produtoSelecionado);
            ResultSet resultSet = statement.executeQuery();

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String dataVenda = resultSet.getString("data_venda");
                String nomeCliente = resultSet.getString("nome_cliente");
                String nomeProduto = resultSet.getString("nome_produto");

                tableModel.addRow(new Object[]{dataVenda, nomeCliente, nomeProduto});
            }

            resultSet.close();
            statement.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    private void pesquisarTodasVendas() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/pitest";
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);

            String sql = "SELECT v.data_venda, c.nome as nome_cliente, p.nome as nome_produto "
                    + "FROM venda v "
                    + "INNER JOIN cliente c ON v.id = c.id "
                    + "INNER JOIN item_venda vp ON v.id = vp.id_venda "
                    + "INNER JOIN produto p ON vp.id_produto = p.id ";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String dataVenda = resultSet.getString("data_venda");
                String nomeCliente = resultSet.getString("nome_cliente");
                String produto = resultSet.getString("nome_produto");

                tableModel.addRow(new Object[]{dataVenda, nomeCliente, produto});
            }

            resultSet.close();
            statement.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void abrirTela() {
        SwingUtilities.invokeLater(() -> {
            TelaGrafico tela = new TelaGrafico("Gráficos de Vendas");
            tela.pack();
            tela.setSize(800, 600);
            tela.setLocationRelativeTo(null);
            tela.setVisible(true);
        });
    }

    public static void tornarVisivel() {
        if (instancia != null) {
            instancia.setVisible(true);
        }
    }

    public static void main(String[] args) {
        abrirTela();
    }
}
