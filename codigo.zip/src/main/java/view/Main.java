package view;

import view.MenuPrincipal;

public class Main {
    public static void main(String[] args){
        MenuPrincipal menuPrincipal = new MenuPrincipal (); 
        menuPrincipal.setVisible(true);
            
       // menuPrincipal.setResizable(false);
     
    }
}
