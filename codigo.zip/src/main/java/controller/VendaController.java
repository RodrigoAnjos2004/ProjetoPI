package controller;

import model.Venda;
import model.ItemVenda;
import dao.VendaDAO;
import java.util.ArrayList;

/**
 * @author RodrigoSilva
 */
public class VendaController {

    public static boolean salvar(Venda v, ArrayList<ItemVenda> iv) throws ClassNotFoundException {
        if (v == null) {
            System.out.println("Venda Inválida!");
            return false;
        }

        if (iv == null || iv.size() == 0) {
            System.out.println("ItemVenda Inválido!");
            return false;
        }

        return VendaDAO.salvar(v, iv);
    }
}
